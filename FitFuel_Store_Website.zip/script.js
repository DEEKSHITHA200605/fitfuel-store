
function addToCart(product) {
  alert(product + " has been added to your cart!");
}
